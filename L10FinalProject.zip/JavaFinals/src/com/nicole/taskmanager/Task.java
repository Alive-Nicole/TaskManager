package com.nicole.taskmanager;

public interface Task {
	String getTask();
}
