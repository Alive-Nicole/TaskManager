package com.nicole.taskmanager;

public class TaskManager {
	// Main Menu Method
		public void mainMenu() {
			System.out.println("1. Add a task");
			System.out.println("2. Remove a task");
			System.out.println("3. Mark a task complete");
			System.out.println("4. List the tasks");
			System.out.println("    ");
			System.out.println("What would you like to do?");
		}	
}